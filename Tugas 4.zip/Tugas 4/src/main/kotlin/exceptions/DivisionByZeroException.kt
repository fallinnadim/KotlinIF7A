package exceptions

class DivisionByZeroException : Exception("Pembagian oleh 0 tidak diizinkan"){
}