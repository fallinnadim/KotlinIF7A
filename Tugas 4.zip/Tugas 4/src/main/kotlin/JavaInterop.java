public class JavaInterop {
    public static void printMessage () {
        System.out.println("Terima Kasih Bu Triana telah mengajarkan saya Java ^_^");
    }
}
